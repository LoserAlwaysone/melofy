const videoIds = [
  { id: "dQw4w9WgXcQ", title: "Never Gonna Give You Up", artist: "Rick Astley" },
  { id: "kxopViU98Xo", title: "Dame Tu Cosita", artist: "El Chombo" }
];

const songList = document.getElementById('songList');
const mainPlayer = document.getElementById('mainPlayer');
const nowPlaying = document.getElementById('nowPlaying');

videoIds.forEach(({ id, title, artist }) => {
  const songCard = document.createElement('div');
  songCard.className = 'song';
  songCard.innerHTML = `
    <img src="https://i.ytimg.com/vi/${id}/hqdefault.jpg" alt="${title} Thumbnail" />
    <p><strong>${title}</strong><br>${artist}</p>
    <button onclick="playSong('${id}', '${title}', '${artist}')">Play</button>
  `;
  songList.appendChild(songCard);
});

async function playSong(videoId, title, artist) {
  try {
    const res = await fetch(`/api/audio/${videoId}`);
    if (!res.ok) throw new Error('Network response not ok');
    const data = await res.json();
    mainPlayer.src = data.audioUrl;
    nowPlaying.textContent = `${title} — ${artist}`;
    mainPlayer.play();
  } catch (err) {
    alert('Failed to load audio.');
    console.error(err);
  }
}
